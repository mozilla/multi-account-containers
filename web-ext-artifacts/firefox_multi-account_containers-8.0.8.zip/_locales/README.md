# Multi-Account Containers Localization
Localization for the Firefox Multi-Account Containers add-on

The application code with build instructions can be found
at <https://github.com/mozilla/multi-account-containers>.

# License
Translations in this repository are available under the
terms of the [Mozilla Public License v2.0](https://www.mozilla.org/MPL/2.0/).
